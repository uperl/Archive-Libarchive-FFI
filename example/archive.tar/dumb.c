void *deref(void **ptr)
{
  return *ptr;
}
